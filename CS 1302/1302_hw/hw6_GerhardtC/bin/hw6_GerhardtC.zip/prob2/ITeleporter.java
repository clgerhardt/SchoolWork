package prob2;

public interface ITeleporter {
	
	public abstract String teleport(String dest);
	
}
