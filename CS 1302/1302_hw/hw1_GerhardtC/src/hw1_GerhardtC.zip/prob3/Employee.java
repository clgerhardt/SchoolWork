package prob3;

public class Employee {

private double[] hours = new double [7];
private String name;

public Employee (String name){
	this.name = name;
	
}
public double getHours(int day){
	
	return hours[day];

}
public void setHours(int day, double hours){
	this.hours[day] = hours;
}
public int numbDaysWorked(){
	int count = 0;
	for(int i = 0; i < hours.length; i++){
		if(hours[i] > 0)
			count += 1;
}
	return count;
			
}
public double totalHours(){
	int sum = 0;
	for(int i = 0; i < hours.length; i++){
		sum = (int)(sum + hours[i]);
}
	return sum;
}
public String toString(){
	return name + " worked " + numbDaysWorked() + " days " 
			+ " for a total of " + totalHours() + " hours.";
}
}
