package prob1;

public interface ITeleporter {
	
	public String teleport(String dest);

}
