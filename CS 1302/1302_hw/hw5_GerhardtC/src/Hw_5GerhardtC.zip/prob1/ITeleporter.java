package prob1;

public interface ITeleporter {
	
	 String teleport(String dest);
	 
	 

}
